TOKEN = '6007283179:AAGkMZbWkBrX0P-HGQZsI-Td75_Peq_fW-Y'

keys = {
    'рубль':'RUB',
    'евро':'EUR',
    'доллар':'USD'
}